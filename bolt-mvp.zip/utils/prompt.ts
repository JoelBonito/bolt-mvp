export const SMILE_PROMPT = `
Aplique facetas dentárias em todos os dentes visíveis.
Use resina composta cor BL3. Nos dentes 12, 11, 21 e 22, mantenha bordas incisais translúcidas (técnica estratificada).
NÃO altere gengiva, lábios, pele, barba/cabelo/olhos, roupas, expressão, largura da boca, formato do rosto, iluminação, fundo ou proporções.
Preserve exatamente a posição, o formato e o alinhamento atuais da boca. Resultado clínico e realista.
`;
