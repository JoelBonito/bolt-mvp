module.exports = { reactStrictMode: true, experimental: { runtime: 'edge' } }
